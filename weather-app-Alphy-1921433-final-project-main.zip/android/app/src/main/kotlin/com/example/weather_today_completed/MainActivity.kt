package com.example.weather_today_completed

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
